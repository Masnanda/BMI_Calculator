//
//  ViewController.swift
//  BMICALCULATOR
//
//  Created by prk on 19/01/22.
//  Copyright © 2022 prk. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //outlet
    @IBOutlet weak var Hitung: UIButton!
    @IBOutlet weak var tb_weight: UITextField!
    @IBOutlet weak var tb_height: UITextField!
    @IBOutlet weak var label_bmi: UILabel!
    @IBOutlet weak var label_hr: UILabel!
    
    //action
    @IBAction func Weight(_ sender: UITextField) {
        sender.resignFirstResponder()
        
    }
    @IBAction func CalculateBMI(_ sender: Any) {
        self.view.endEditing(true)
        
        let height=(tb_height.text! as NSString).doubleValue
        let weight=(tb_weight.text! as NSString).doubleValue
        let bmi=weight/pow(height,2)
        label_bmi.text=String(format:"%.2f",bmi)
        
        if bmi < 18.5 {
            label_hr.text="Risk of developing problems such as nutritional deficiency and osteoporosis"
            
        }else if bmi < 23
        {
            label_hr.text="low Risk (Healty range)"
        }else if bmi < 27.5
        {
            label_hr.text="Moderate risk of developing heart disease, high blood pressure, stroke, diabetes."
        }else {
            label_hr.text="High risk of developing heart disease, high blood pressure, stroke, diabetes."
            
        }
    
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        label_bmi.text=""
        label_hr.text=""
        
    }
    

}

